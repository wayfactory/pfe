# Paramos el servicio wordpress arrancado previamente y el sql
kubectl delete deployment,service -l app=wordpress
kubectl delete secret mysql-pass
# Desmontamos los volumenes compartidos
kubectl delete pvc -l app=wordpress
kubectl delete pv local-pv-1 local-pv-2
