# Montamos una carpeta compartida con el host para la DB MySQL
kubectl create -f local-volumes.yaml

# Le pasamos la pass del SQL para acceder a la DB del WordPress
kubectl create secret generic mysql-pass --from-file=password.txt

# Desplegamos el MySQL
kubectl create -f ./desplegar_mysql.yaml

# Desplegamos el WordPress
kubectl create -f ./desplegar_wordpress.yaml
